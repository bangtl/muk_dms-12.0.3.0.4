`2.1.0`
-------

- Added Python Expressions

`2.0.0`
-------

- Migrated to Python 3

`1.1.0`
-------

- Add field selector


`1.0.0`
-------

- Init version
